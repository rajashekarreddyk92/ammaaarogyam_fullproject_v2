import express from 'express';
import { supabase } from '../lib/supabaseClient';
import { stripe } from '../lib/stripeClient';
const router = express.Router();

router.post('/create', async (req, res) => {
  try {
    const { cartId, user_id, shipping_address } = req.body;
    const cartItemsResp = await supabase.from('cart_items').select('*').eq('cart_id', cartId);
    if (cartItemsResp.error) throw cartItemsResp.error;
    const items = cartItemsResp.data;
    if (!items || items.length === 0) return res.status(400).json({ error: 'Cart empty' });

    let total = 0;
    for (const it of items) {
      total += parseFloat(it.unit_price) * it.quantity;
    }

    const paymentIntent = await stripe.paymentIntents.create({
      amount: Math.round(total * 100),
      currency: 'inr',
      metadata: { cartId, user_id }
    });

    const orderResp = await supabase.from('orders').insert({ user_id, status: 'pending', total_amount: total, currency: 'INR', stripe_payment_intent: paymentIntent.id, shipping_address }).select().single();
    if (orderResp.error) throw orderResp.error;
    const order = orderResp.data;

    for (const it of items) {
      await supabase.from('order_items').insert({ order_id: order.id, product_id: it.product_id, quantity: it.quantity, unit_price: it.unit_price });
    }

    res.json({ clientSecret: paymentIntent.client_secret, orderId: order.id });
  } catch (err: any) {
    console.error(err);
    res.status(500).json({ error: err.message });
  }
});

router.get('/:id', async (req, res) => {
  try {
    const { id } = req.params;
    const orderResp = await supabase.from('orders').select('*').eq('id', id).single();
    if (orderResp.error) throw orderResp.error;
    const itemsResp = await supabase.from('order_items').select('*,products(*)').eq('order_id', id);
    if (itemsResp.error) throw itemsResp.error;
    res.json({ order: orderResp.data, items: itemsResp.data });
  } catch (err: any) {
    console.error(err);
    res.status(404).json({ error: 'Order not found' });
  }
});

export default router;
