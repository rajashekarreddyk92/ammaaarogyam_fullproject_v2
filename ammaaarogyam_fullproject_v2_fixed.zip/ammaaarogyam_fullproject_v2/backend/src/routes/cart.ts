import express from 'express';
import { supabase } from '../lib/supabaseClient';
const router = express.Router();

router.post('/', async (req, res) => {
  try {
    const { user_id } = req.body;
    const { data, error } = await supabase.from('carts').insert({ user_id }).select().single();
    if (error) throw error;
    res.status(201).json({ data });
  } catch (err: any) {
    console.error(err);
    res.status(400).json({ error: err.message });
  }
});

router.get('/:cartId/items', async (req, res) => {
  try {
    const { cartId } = req.params;
    const { data, error } = await supabase.from('cart_items').select('*,products(*)').eq('cart_id', cartId);
    if (error) throw error;
    res.json({ data });
  } catch (err: any) {
    console.error(err);
    res.status(400).json({ error: err.message });
  }
});

router.post('/:cartId/items', async (req, res) => {
  try {
    const { cartId } = req.params;
    const { product_id, quantity = 1 } = req.body;
    const p = await supabase.from('products').select('price').eq('id', product_id).single();
    if (p.error) throw p.error;
    const unit_price = p.data.price;
    const existing = await supabase.from('cart_items').select('*').eq('cart_id', cartId).eq('product_id', product_id).single();
    if (!existing.error && existing.data) {
      const newQty = existing.data.quantity + quantity;
      const upd = await supabase.from('cart_items').update({ quantity: newQty }).eq('id', existing.data.id).select().single();
      if (upd.error) throw upd.error;
      return res.json({ data: upd.data });
    }
    const { data, error } = await supabase.from('cart_items').insert({ cart_id: cartId, product_id, quantity, unit_price }).select().single();
    if (error) throw error;
    res.status(201).json({ data });
  } catch (err: any) {
    console.error(err);
    res.status(400).json({ error: err.message });
  }
});

router.delete('/:cartId/items/:itemId', async (req, res) => {
  try {
    const { itemId } = req.params;
    const { data, error } = await supabase.from('cart_items').delete().eq('id', itemId).select().single();
    if (error) throw error;
    res.json({ data });
  } catch (err: any) {
    console.error(err);
    res.status(400).json({ error: err.message });
  }
});

export default router;
