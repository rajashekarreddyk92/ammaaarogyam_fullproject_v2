import express from 'express';
import { supabase } from '../lib/supabaseClient';
const router = express.Router();

router.get('/', async (req, res) => {
  try {
    const { category, q, limit = '50', offset = '0' } = req.query as any;
    if (q) {
      const { data, error } = await supabase.from('products').select('*').or(`name.ilike.%${q}%,description.ilike.%${q}%`).order('created_at', { ascending: false }).range(parseInt(offset), parseInt(offset) + parseInt(limit) - 1);
      if (error) throw error;
      return res.json({ data });
    }
    let query = supabase.from('products').select('*').order('created_at', { ascending: false }).range(parseInt(offset), parseInt(offset) + parseInt(limit) - 1);
    if (category) query = supabase.from('products').select('*').eq('category', category).order('created_at', { ascending: false }).range(parseInt(offset), parseInt(offset) + parseInt(limit) - 1);
    const { data, error } = await query;
    if (error) throw error;
    res.json({ data });
  } catch (err: any) {
    console.error(err);
    res.status(500).json({ error: err.message || 'Server error' });
  }
});

router.get('/:id', async (req, res) => {
  try {
    const { id } = req.params;
    const { data, error } = await supabase.from('products').select('*').eq('id', id).limit(1).single();
    if (error) {
      const resp = await supabase.from('products').select('*').eq('slug', id).limit(1).single();
      if (resp.error) throw resp.error;
      return res.json({ data: resp.data });
    }
    res.json({ data });
  } catch (err: any) {
    console.error(err);
    res.status(404).json({ error: 'Product not found' });
  }
});

router.post('/', async (req, res) => {
  try {
    const payload = req.body;
    const { data, error } = await supabase.from('products').insert(payload).select().single();
    if (error) throw error;
    res.status(201).json({ data });
  } catch (err: any) {
    console.error(err);
    res.status(400).json({ error: err.message || 'Bad request' });
  }
});

export default router;
