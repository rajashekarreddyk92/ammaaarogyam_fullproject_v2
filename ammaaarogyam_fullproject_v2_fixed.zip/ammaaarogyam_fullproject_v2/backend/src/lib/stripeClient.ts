import Stripe from 'stripe';
import dotenv from 'dotenv';
dotenv.config();

const stripeSecret = process.env.STRIPE_SECRET_KEY as string;
if (!stripeSecret) throw new Error('Missing STRIPE_SECRET_KEY in .env');
export const stripe = new Stripe(stripeSecret, { apiVersion: '2024-08-01' });
