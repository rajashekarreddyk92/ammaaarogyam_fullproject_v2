import express from 'express';
import { stripe } from '../lib/stripeClient';
import dotenv from 'dotenv';
import { supabase } from '../lib/supabaseClient';
dotenv.config();

const webhookSecret = process.env.STRIPE_WEBHOOK_SECRET as string;

const router = express.Router();

router.post('/', express.raw({ type: 'application/json' }), async (req, res) => {
  const sig = req.headers['stripe-signature'] as string | undefined;
  if (!sig || !webhookSecret) return res.status(400).send('Webhook signature or secret missing');

  let event;
  try {
    event = stripe.webhooks.constructEvent(req.body, sig, webhookSecret);
  } catch (err: any) {
    console.error('Webhook signature verification failed.', err.message);
    return res.status(400).send(`Webhook Error: ${err.message}`);
  }

  switch (event.type) {
    case 'payment_intent.succeeded':
      {
        const intent = event.data.object as any;
        const paymentIntentId = intent.id;
        try {
          const orderResp = await supabase.from('orders').update({ status: 'paid' }).eq('stripe_payment_intent', paymentIntentId).select();
          console.log('Order updated to paid', orderResp.data);
        } catch (e) {
          console.error('Failed to update order status', e);
        }
      }
      break;
    case 'payment_intent.payment_failed':
      {
        const intent = event.data.object as any;
        const paymentIntentId = intent.id;
        try {
          await supabase.from('orders').update({ status: 'failed' }).eq('stripe_payment_intent', paymentIntentId);
        } catch (e) {
          console.error('Failed to mark order failed', e);
        }
      }
      break;
    default:
      console.log(`Unhandled event type ${event.type}`);
  }

  res.json({ received: true });
});

export default router;
