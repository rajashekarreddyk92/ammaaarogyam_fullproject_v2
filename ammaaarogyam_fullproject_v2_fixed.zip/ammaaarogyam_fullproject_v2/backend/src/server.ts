import express from 'express';
import dotenv from 'dotenv';
import cors from 'cors';
import bodyParser from 'body-parser';
import productsRouter from './routes/products';
import cartRouter from './routes/cart';
import ordersRouter from './routes/orders';
import authRouter from './routes/auth';
import stripeWebhook from './webhooks/stripeWebhook';
import path from 'path';

dotenv.config();

const app = express();
const PORT = process.env.PORT ? parseInt(process.env.PORT) : 4000;
const FRONTEND_URL = process.env.FRONTEND_URL || 'http://localhost:5173';

// CORS - allow frontend origin in development
app.use(cors({ origin: FRONTEND_URL }));

// Mount webhook before JSON parser (stripe requires raw body)
app.use('/webhook/stripe', stripeWebhook);

// JSON body parser for other routes
app.use(bodyParser.json());

app.use('/api/products', productsRouter);
app.use('/api/cart', cartRouter);
app.use('/api/orders', ordersRouter);
app.use('/api/auth', authRouter);

app.get('/api/health', (req, res) => res.json({ status: 'ok', uptime: process.uptime() }));

// In production you might serve built frontend from /frontend/dist
if (process.env.NODE_ENV === 'production') {
  const distPath = path.join(__dirname, '../../frontend_dist');
  app.use(express.static(distPath));
  app.get('*', (req, res) => res.sendFile(path.join(distPath, 'index.html')));
}

app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});
