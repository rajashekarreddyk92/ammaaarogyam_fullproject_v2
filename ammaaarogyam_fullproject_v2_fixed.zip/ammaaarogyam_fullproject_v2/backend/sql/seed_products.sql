-- Seed products for AmmaAarogyam
INSERT INTO products (id, name, slug, description, price, currency, stock, category, image_url)
VALUES
  (gen_random_uuid(), 'Peanut Laddu', 'peanut-laddu', 'Traditional peanut laddu made with jaggery', 150.00, 'INR', 100, 'Sweets', ''),
  (gen_random_uuid(), 'Sesame Laddu', 'sesame-laddu', 'Crisp sesame laddu', 140.00, 'INR', 120, 'Sweets', ''),
  (gen_random_uuid(), 'Avakaya - Andhra Mango Pickle', 'avakaya-mango-pickle', 'Classic spicy Andhra mango pickle', 250.00, 'INR', 50, 'Pickles', '');
