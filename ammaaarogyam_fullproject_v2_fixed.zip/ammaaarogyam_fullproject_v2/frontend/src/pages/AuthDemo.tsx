import React, { useState } from 'react';
import { createClient } from '@supabase/supabase-js';

const supabase = createClient(import.meta.env.VITE_SUPABASE_URL || '', import.meta.env.VITE_SUPABASE_ANON_KEY || '');

export default function AuthDemo(){
  const [email, setEmail] = useState('');
  const [msg, setMsg] = useState('');
  async function signIn(){
    const { data, error } = await supabase.auth.signInWithOtp({ email });
    if (error) setMsg('Error: '+error.message);
    else setMsg('Magic link sent — check your email');
  }
  async function signOut(){
    await supabase.auth.signOut();
    setMsg('Signed out');
  }
  return (
    <div>
      <h2 className="text-2xl font-semibold mb-4">Auth (Supabase demo)</h2>
      <div className="max-w-md">
        <input value={email} onChange={e=>setEmail(e.target.value)} placeholder="you@example.com" className="w-full p-2 border rounded mb-2" />
        <button onClick={signIn} className="bg-blue-600 text-white px-3 py-1 rounded mr-2">Send Magic Link</button>
        <button onClick={signOut} className="bg-gray-300 px-3 py-1 rounded">Sign Out</button>
        <div className="mt-3 text-sm text-gray-700">{msg}</div>
      </div>
    </div>
  );
}
