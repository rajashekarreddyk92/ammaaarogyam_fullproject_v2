import React, { useState } from 'react';
import { loadStripe } from '@stripe/stripe-js';

const stripePromise = loadStripe(import.meta.env.VITE_STRIPE_PUBLISHABLE_KEY || '');

export default function Checkout(){
  const [status, setStatus] = useState('');
  const [clientSecret, setClientSecret] = useState<string | null>(null);

  async function startPayment(){
    setStatus('Creating payment...');
    const resp = await fetch('/api/orders/create', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ cartId: null, user_id: null })
    });
    const j = await resp.json();
    if (!j.clientSecret) {
      setStatus('Failed to create PaymentIntent: ' + (j.error || 'unknown'));
      return;
    }
    setClientSecret(j.clientSecret);
    setStatus('PaymentIntent created. Integrate Stripe Elements to collect card details and confirm payment using the client secret.');
  }

  return (
    <div>
      <h2 className="text-2xl font-semibold mb-4">Checkout (Demo)</h2>
      <p className="mb-4">This page demonstrates creating a PaymentIntent on the server. For production, implement Stripe Elements on the frontend to securely collect card details and confirm payment.</p>
      <button onClick={startPayment} className="bg-green-600 text-white px-4 py-2 rounded">Create PaymentIntent</button>
      <div className="mt-4">Status: {status}</div>
      {clientSecret && (
        <div className="mt-4 p-3 bg-gray-100 rounded">
          <div><strong>Client Secret (demo)</strong></div>
          <code style={{wordBreak: 'break-all'}}>{clientSecret}</code>
          <div className="text-sm text-gray-600 mt-2">Use this client secret with Stripe Elements to finish the payment on the client.</div>
        </div>
      )}
    </div>
  );
}
