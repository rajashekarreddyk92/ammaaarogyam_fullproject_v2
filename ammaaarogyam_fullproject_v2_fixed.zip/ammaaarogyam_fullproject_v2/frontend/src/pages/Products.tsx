import React, { useEffect, useState } from 'react';

type Product = { id: string; name: string; description?: string; price: number };

export default function Products(){
  const [products, setProducts] = useState<Product[]>([]);
  useEffect(()=>{ fetch('/api/products').then(r=>r.json()).then(j=>setProducts(j.data || [])); },[]);
  return (
    <div>
      <h2 className="text-2xl font-semibold mb-4">Products</h2>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {products.map(p=> (
          <div key={p.id} className="bg-white p-4 rounded shadow">
            <div className="h-32 bg-gray-100 rounded flex items-center justify-center text-3xl">{p.name.charAt(0)}</div>
            <h3 className="mt-2 font-semibold">{p.name}</h3>
            <p className="text-sm text-gray-600">{p.description}</p>
            <div className="mt-2 flex items-center justify-between">
              <div className="font-bold">₹{p.price}</div>
              <button className="bg-indigo-600 text-white px-3 py-1 rounded">Add</button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
