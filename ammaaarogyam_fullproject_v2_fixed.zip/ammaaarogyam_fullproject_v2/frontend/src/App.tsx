import React from 'react';
import { Routes, Route, Link } from 'react-router-dom';
import Products from './pages/Products';
import Checkout from './pages/Checkout';
import AuthDemo from './pages/AuthDemo';

export default function App(){
  return (
    <div className="min-h-screen bg-gray-50">
      <header className="bg-white shadow">
        <div className="max-w-6xl mx-auto px-4 py-4 flex items-center justify-between">
          <h1 className="text-xl font-bold">AmmaAarogyam</h1>
          <nav className="space-x-4">
            <Link to="/">Products</Link>
            <Link to="/checkout">Checkout</Link>
            <Link to="/auth">Auth</Link>
          </nav>
        </div>
      </header>
      <main className="max-w-6xl mx-auto p-4">
        <Routes>
          <Route path="/" element={<Products/>} />
          <Route path="/checkout" element={<Checkout/>} />
          <Route path="/auth" element={<AuthDemo/>} />
        </Routes>
      </main>
    </div>
  );
}
