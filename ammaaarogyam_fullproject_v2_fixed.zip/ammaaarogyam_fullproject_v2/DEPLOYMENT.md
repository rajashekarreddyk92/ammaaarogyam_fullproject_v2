Deployment notes

Render:
- Create two services: a Web Service for backend and a Static Site for frontend.
- For backend, set the build command to `npm install && npm run build` and start command `npm run start`.
- Add environment variables in Render dashboard: SUPABASE_*, STRIPE_*, FRONTEND_URL.
- For webhook, configure Stripe to send events to https://<your-backend>/webhook/stripe.

Cloud Run (Google):
- Build container images for backend and frontend (or serve frontend via CDN).
- Use the backend Dockerfile. Push to Container Registry and deploy to Cloud Run. Set env vars.

Vercel:
- Deploy frontend by connecting the frontend folder to Vercel. Set environment variables VITE_SUPABASE_URL, VITE_SUPABASE_ANON_KEY, VITE_STRIPE_PUBLISHABLE_KEY.
- Backend can be deployed to Render/Cloud Run; Vercel Serverless functions are possible but this repo is designed for Node server.
