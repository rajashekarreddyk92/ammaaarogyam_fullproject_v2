AmmaAarogyam — Full project (backend + frontend)

Quickstart (local):
1. Backend:
   - cd backend
   - copy .env.example -> .env and fill values
   - npm install
   - npm run dev

2. Frontend (dev):
   - cd frontend
   - copy .env example values to .env (VITE_SUPABASE_URL, VITE_SUPABASE_ANON_KEY, VITE_STRIPE_PUBLISHABLE_KEY)
   - npm install
   - npm run dev

Docker (optional):
- docker-compose up --build

Files of interest:
- backend/src : Express server and routes
- frontend/src : React + Vite + Tailwind app
- backend/sql/: schema + seed
- postman_collection.json : Postman collection for API testing

Notes:
- This is scaffolded code to get you started. You must supply Supabase and Stripe keys and configure the database.
- For full Stripe Elements integration on frontend, follow Stripe docs and include Elements components.
